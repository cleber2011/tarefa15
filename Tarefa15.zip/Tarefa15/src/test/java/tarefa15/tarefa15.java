//01 - pacote
package tarefa15;

//02 - bibliotecas


import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;

//03 - classes
public class tarefa15 {
    //3.1 - Atributos = Características
    String url;
    WebDriver driver;
    String pastaPrint = "evidencias/" + new SimpleDateFormat("yyyy-MM-dd HH-mm").format(Calendar.getInstance().getTime()) + "/";

    //3.2 - métodos ou funções
    //métodos ou funções de apoio (util/commons)
    public void tirarPrint(String nomePrint) throws IOException {
        File foto = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(foto,new File(pastaPrint + nomePrint +".png"));
    }

    //3.2 - Métodos e funcionalidades = O que vai fazer (método executa sem retorno)
    @Before
    public void iniciar() {
        url = "https://www.americanas.com.br/"; // declarando o conteúdo da String url
        // Ligação do Webdriver Selenium com o Chrome (browser)
        System.setProperty("webdriver.chrome.driver", "drivers/chrome/87/chromedriver.exe");

        //Instanciar o objeto Selenium WebDriver
        driver = new ChromeDriver();
        driver.manage().window().maximize(); // maximiza a tela
        driver.manage().timeouts().implicitlyWait(3000, TimeUnit.MILLISECONDS);



    }
    @After
    public void finalizar (){
        //driver.quit(); // finalizar(destroi) o objeto Selenium Webdriver

    }

    @Test
    public void consultarProduto () throws IOException, InterruptedException {
        driver.get(url);
        tirarPrint("01 - Acesso ao site da Americanas");
        driver.findElement(By.id("lgpd-accept")).click();
        driver.findElement(By.id("h_search-input")).sendKeys(Keys.chord("samsung s10") + Keys.ENTER);
        Thread.sleep(2000);
        tirarPrint("02 - Resultado da pesquisa");
        driver.findElement(By.cssSelector("span.src__Text-sc-154pg0p-0.src__Name-sc-1di8q3f-3.fLqTUE")).click();
        Thread.sleep(2000);
        tirarPrint("03 - Selecione o produto");
        // Validar valor em 1x no cartão de crédito
        assertEquals("Smartphone Samsung Galaxy S10e, Galaxy S10e, S10e, 128GB, 6GB RAM, Tela Infinita de 5.8\", Camera Dupla Traseira 12MP + 16MP, Camera Frontal de 10MP, IP68, Bateria de 3100mAh, Power Share, Leitor de Digital, Dual Chip, Android, flash...",driver.findElement(By.cssSelector("span.src__Text-sc-154pg0p-0.description-text__TextUI-lvc0qt-0.dqsgJI")).getText());
        assertEquals("R$ 1.999,00",driver.findElement(By.cssSelector("div.src__BestPrice-lo2vta-5.bFIChl.priceSales")).getText());

    }

}
